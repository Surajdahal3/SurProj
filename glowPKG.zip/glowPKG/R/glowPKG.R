#' glowPKG Package
#'
#' More about what it does (maybe more than one line)
#'
#'
#' @docType package
#'
#' @author Suraj D \email{youremail@gmail.com}
#'
#' @name glowPKG
NULL
